import React from 'react';
import { Link } from 'react-router-dom';

export default function Refund() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-100 prose prose-slate">
        <h2>Refund and Cancellation Policy</h2>
        <p>We strive to provide the best career guidance possible.</p>
        <h3>1. Digital Goods</h3>
        <p>Since our premium reports are digital goods generated instantly upon payment, we generally do not offer refunds once the report has been generated and accessed.</p>
        <h3>2. Exceptions</h3>
        <p>If you experience a technical error where payment was deducted but the premium report was not generated, please contact us within 7 days for a full refund.</p>
        <h3>3. Processing Time</h3>
        <p>Approved refunds will be processed within 5-7 business days and credited back to the original payment method.</p>
        <Link to="/" className="inline-block mt-8 text-indigo-600 hover:text-indigo-800 font-medium">&larr; Back to Home</Link>
      </div>
    </div>
  );
}
