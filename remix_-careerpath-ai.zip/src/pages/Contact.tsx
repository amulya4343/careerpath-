import React from 'react';
import { Link } from 'react-router-dom';

export default function Contact() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-100 prose prose-slate">
        <h2>Contact Us</h2>
        <p>We'd love to hear from you. If you have any questions, issues, or feedback, please reach out to us.</p>
        <div className="mt-6 space-y-4">
          <p><strong>Email:</strong> support@careerpathai.in</p>
          <p><strong>Phone:</strong> +91 98765 43210</p>
          <p><strong>Address:</strong> 123 Tech Park, Bangalore, Karnataka, India - 560001</p>
        </div>
        <Link to="/" className="inline-block mt-8 text-indigo-600 hover:text-indigo-800 font-medium">&larr; Back to Home</Link>
      </div>
    </div>
  );
}
