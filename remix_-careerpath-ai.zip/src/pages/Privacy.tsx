import React from 'react';
import { Link } from 'react-router-dom';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-slate-100 prose prose-slate">
        <h2>Privacy Policy</h2>
        <p>Your privacy is important to us.</p>
        <h3>1. Data Collection</h3>
        <p>We collect the skills and career interests you input to generate your personalized report. We do not store your payment information on our servers; it is securely handled by Razorpay.</p>
        <h3>2. Data Usage</h3>
        <p>Your data is used solely to generate your career report and improve our AI models.</p>
        <h3>3. Third-Party Services</h3>
        <p>We use Google Gemini AI for generating reports and Razorpay for processing payments.</p>
        <Link to="/" className="inline-block mt-8 text-indigo-600 hover:text-indigo-800 font-medium">&larr; Back to Home</Link>
      </div>
    </div>
  );
}
