import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, BookOpen, Briefcase, GraduationCap, Search, Sparkles, Lock, CheckCircle, CreditCard, X, Bell, MapPin, Building2, QrCode, PlayCircle, Calendar, Code, BriefcaseBusiness, ExternalLink, Award, Users, FileText, MessageSquare, ShieldCheck, Loader2, Target, Rocket, DollarSign, Layers, TrendingUp } from 'lucide-react';
import { Button, Card } from './ui';
import { analyzeSkills, suggestPathByBranch, type CareerAnalysisData } from '../services/gemini';
import ReactMarkdown from 'react-markdown';
import { QRCodeSVG } from 'qrcode.react';

type ViewState = 'initial' | 'skills-input' | 'branch-input' | 'loading' | 'results' | 'terms' | 'privacy' | 'refund' | 'contact';

export default function CareerAssistant() {
  const [view, setView] = useState<ViewState>('initial');
  const [inputValue, setInputValue] = useState('');
  const [result, setResult] = useState<CareerAnalysisData | null>(null);
  const [mode, setMode] = useState<'skills' | 'branch'>('skills');
  const [isPremium, setIsPremium] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'options' | 'upi-qr'>('options');

  const [error, setError] = useState<string | null>(null);

  const handleStartSkills = () => {
    setMode('skills');
    setView('skills-input');
    setInputValue('');
    setError(null);
  };

  const handleStartFresh = () => {
    setMode('branch');
    setView('branch-input');
    setInputValue('');
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    setView('loading');
    setError(null);
    try {
      let response: CareerAnalysisData;
      if (mode === 'skills') {
        response = await analyzeSkills(inputValue);
      } else {
        response = await suggestPathByBranch(inputValue);
      }
      setResult(response);
      setView('results');
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong. Please try again.");
      setView('results'); 
    }
  };

  const handleReset = () => {
    setView('initial');
    setInputValue('');
    setResult(null);
    setIsPremium(false);
    setError(null);
    setPaymentStep('options');
  };

  const loadRazorpayScript = () => {
    return new Promise((resolve) => {
      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  const [isVerifying, setIsVerifying] = useState(false);
  const [showUtrInput, setShowUtrInput] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');
  const [utrError, setUtrError] = useState('');

  const handleUnlock = async () => {
    // Skip Razorpay entirely and just show the custom QR code modal
    setPaymentStep('upi-qr');
    setShowPaymentModal(true);
    setShowUtrInput(false);
    setUtrNumber('');
    setUtrError('');
  };

  const handlePaymentSuccess = () => {
    if (!showUtrInput) {
      setShowUtrInput(true);
      return;
    }

    if (utrNumber.length !== 12 || !/^\d+$/.test(utrNumber)) {
      setUtrError('Please enter a valid 12-digit UTR / Transaction ID.');
      return;
    }

    setUtrError('');
    setIsVerifying(true);
    // Simulate a brief verification delay for better UX
    setTimeout(() => {
      setIsVerifying(false);
      setShowPaymentModal(false);
      setIsPremium(true);
    }, 2500);
  };

  // Replace with your actual UPI ID and Name
  // Replace with your actual UPI ID and Name
  const upiId = "8088023162@ibl";
  const payeeName = "CareerPath AI";
  const amount = "99.00";
  const upiLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=Premium%20Report`;

  return (
    <div className="min-h-screen bg-[#0a051a] text-white font-sans selection:bg-brand-500/30 selection:text-white">
      <div className="mesh-bg" />
      
      <header className="border-b border-white/5 sticky top-0 z-50 bg-[#0a051a]/80 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={handleReset}>
            <div className="bg-brand-600 p-2.5 rounded-xl shadow-lg shadow-brand-500/20 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className="font-bold text-2xl tracking-tight glow-text">CareerPath AI</span>
          </div>
          {view === 'results' && !isPremium && (
             <Button variant="primary" onClick={handleUnlock} className="bg-amber-500 hover:bg-amber-600 text-white shadow-amber-200">
               <Lock className="w-4 h-4 mr-2" /> Unlock Premium
             </Button>
          )}
          {isPremium && (
             <div className="flex items-center text-amber-600 font-medium bg-amber-50 px-3 py-1 rounded-full border border-amber-100">
               <Sparkles className="w-4 h-4 mr-1" /> Premium Unlocked
             </div>
          )}
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-20">
        <AnimatePresence mode="wait">
          {view === 'initial' && (
            <motion.div
              key="initial"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="text-center space-y-16"
            >
              <div className="space-y-8">
                <h1 className="text-5xl sm:text-7xl font-extrabold tracking-tight leading-[1.1]">
                  Architect Your <br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-indigo-400 glow-text">
                    Future Career
                  </span>
                </h1>
                <p className="text-lg sm:text-xl text-white/60 max-w-2xl mx-auto leading-relaxed font-light">
                  AI-powered precision roadmaps for the next generation of professionals. 
                  <span className="block mt-2 text-brand-300 font-medium">
                    Unlock your potential with data-driven insights.
                  </span>
                </p>
              </div>

              <div className="grid sm:grid-cols-2 gap-8 max-w-3xl mx-auto">
                <div 
                  onClick={handleStartSkills}
                  className="glass-card p-8 hover:bg-white/5 transition-all cursor-pointer group text-left relative overflow-hidden border-brand-500/20 hover:border-brand-500/50"
                >
                  <div className="absolute -top-12 -right-12 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                    <Briefcase className="w-48 h-48 text-brand-400" />
                  </div>
                  <div className="relative z-10 space-y-6">
                    <div className="w-14 h-14 bg-brand-500/20 rounded-2xl flex items-center justify-center text-brand-400 group-hover:scale-110 transition-transform">
                      <Sparkles className="w-7 h-7" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">Skill Mapping</h3>
                      <p className="text-white/50 text-sm leading-relaxed">
                        Reverse-engineer your current skill set to find high-demand industry roles.
                      </p>
                    </div>
                    <div className="flex items-center text-brand-400 font-semibold text-sm group-hover:translate-x-2 transition-transform">
                      Analyze Skills <ArrowRight className="ml-2 w-4 h-4" />
                    </div>
                  </div>
                </div>

                <div 
                  onClick={handleStartFresh}
                  className="glass-card p-8 hover:bg-white/5 transition-all cursor-pointer group text-left relative overflow-hidden border-emerald-500/20 hover:border-emerald-500/50"
                >
                  <div className="absolute -top-12 -right-12 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                    <BookOpen className="w-48 h-48 text-emerald-400" />
                  </div>
                  <div className="relative z-10 space-y-6">
                    <div className="w-14 h-14 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                      <Search className="w-7 h-7" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white mb-2">Roadmap Engine</h3>
                      <p className="text-white/50 text-sm leading-relaxed">
                        Generate a step-by-step learning journey tailored to your academic branch.
                      </p>
                    </div>
                    <div className="flex items-center text-emerald-400 font-semibold text-sm group-hover:translate-x-2 transition-transform">
                      Get Roadmap <ArrowRight className="ml-2 w-4 h-4" />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {(view === 'skills-input' || view === 'branch-input') && (
            <motion.div
              key="input"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-xl mx-auto"
            >
              <div className="glass-card p-8 sm:p-10 border-white/10">
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div className="space-y-3">
                    <h2 className="text-3xl font-bold text-white">
                      {view === 'skills-input' ? 'Skill Inventory' : 'Academic Path'}
                    </h2>
                    <p className="text-white/50 text-sm leading-relaxed">
                      {view === 'skills-input' 
                        ? 'List your technical stack and soft skills to map your career trajectory.' 
                        : 'Specify your field of study to generate a high-precision learning roadmap.'}
                    </p>
                  </div>

                  <div className="relative group">
                    {view === 'skills-input' ? (
                      <textarea
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="e.g. Python, React, AWS, System Design..."
                        className="w-full min-h-[160px] p-5 rounded-2xl bg-white/5 border border-white/10 focus:border-brand-500/50 focus:ring-4 focus:ring-brand-500/10 outline-none resize-none text-white placeholder:text-white/20 text-lg transition-all"
                        autoFocus
                      />
                    ) : (
                      <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="e.g. Computer Science Engineering"
                        className="w-full p-5 rounded-2xl bg-white/5 border border-white/10 focus:border-emerald-500/50 focus:ring-4 focus:ring-emerald-500/10 outline-none text-white placeholder:text-white/20 text-lg transition-all"
                        autoFocus
                      />
                    )}
                  </div>

                  <div className="flex gap-4 pt-2">
                    <Button 
                      type="button" 
                      variant="ghost" 
                      onClick={() => setView('initial')}
                      className="flex-1 border-white/5 hover:bg-white/5"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className={`flex-[2] py-4 text-lg ${view === 'skills-input' ? 'bg-brand-600 hover:bg-brand-700' : 'bg-emerald-600 hover:bg-emerald-700'}`}
                      disabled={!inputValue.trim()}
                    >
                      {view === 'skills-input' ? 'Analyze Trajectory' : 'Generate Roadmap'}
                    </Button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}

          {view === 'loading' && (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-24 space-y-8"
            >
              <div className="relative">
                <div className="w-20 h-20 border-2 border-brand-500/20 border-t-brand-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="w-8 h-8 text-brand-400 animate-pulse" />
                </div>
              </div>
              <div className="text-center space-y-2">
                <p className="text-xl font-medium text-white animate-pulse">
                  {mode === 'skills' ? 'Synthesizing Career Matrix...' : 'Engineering Learning Path...'}
                </p>
                <p className="text-sm text-white/40 font-mono tracking-widest uppercase">
                  Processing via Gemini 3.0
                </p>
              </div>
            </motion.div>
          )}

          {view === 'results' && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-10"
            >
              {error ? (
                <div className="glass-card p-10 border-red-500/20 text-center">
                  <div className="w-20 h-20 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <X className="w-10 h-10" />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Analysis Interrupted</h3>
                  <p className="text-white/60 mb-8">{error}</p>
                  <Button onClick={() => setView(mode === 'skills' ? 'skills-input' : 'branch-input')} className="bg-white/10 hover:bg-white/20">
                    Retry Analysis
                  </Button>
                </div>
              ) : result && (
                <>
                  {/* Career Pulse Section - UNIQUE FEATURE */}
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div className="glass-card p-6 border-brand-500/20">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm font-mono text-brand-400 uppercase tracking-wider">Market Demand Index</span>
                        <span className="text-2xl font-bold text-white">{result.marketDemandIndex}%</span>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${result.marketDemandIndex}%` }}
                          className="h-full bg-gradient-to-r from-brand-600 to-indigo-400"
                        />
                      </div>
                      <p className="text-xs text-white/40 mt-3">Current industry requirement for this profile.</p>
                    </div>
                    <div className="glass-card p-6 border-emerald-500/20">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm font-mono text-emerald-400 uppercase tracking-wider">Career Confidence</span>
                        <span className="text-2xl font-bold text-white">{result.careerConfidenceScore}%</span>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${result.careerConfidenceScore}%` }}
                          className="h-full bg-gradient-to-r from-emerald-600 to-teal-400"
                        />
                      </div>
                      <p className="text-xs text-white/40 mt-3">Estimated success rate based on current skills.</p>
                    </div>
                  </div>

                  {/* Free Section */}
                  <div className="glass-card p-8 sm:p-10 border-white/10">
                    <h3 className="text-2xl font-bold text-white mb-8 glow-text">Trajectory Analysis</h3>
                    
                    <div className="grid gap-8 sm:grid-cols-2 mb-10">
                      <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                        <h4 className="font-semibold text-white mb-4 flex items-center">
                          <Briefcase className="w-5 h-5 mr-3 text-brand-400" /> Target Roles
                        </h4>
                        <ul className="space-y-3">
                          {result.jobRoles.map((role, i) => (
                            <li key={i} className="text-white/70 flex items-start text-sm">
                              <span className="mr-3 text-brand-500 font-bold">›</span> {role}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                        <h4 className="font-semibold text-white mb-4 flex items-center">
                          <CreditCard className="w-5 h-5 mr-3 text-emerald-400" /> Compensation Range
                        </h4>
                        <p className="text-3xl font-bold text-emerald-400 glow-text">{result.expectedSalary}</p>
                        <p className="text-xs text-white/30 mt-2 font-mono uppercase">Annual Estimate • India Market</p>
                      </div>
                    </div>

                    <div className="bg-white/5 p-6 rounded-2xl border border-white/5">
                       <h4 className="font-semibold text-white mb-4 flex items-center">
                          <BookOpen className="w-5 h-5 mr-3 text-blue-400" /> Essential Skill Gaps
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {result.skillsToLearn.map((skill, i) => (
                            <span key={i} className="bg-white/5 border border-white/10 px-4 py-1.5 rounded-full text-xs text-white/80 hover:bg-white/10 transition-colors">
                              {skill}
                            </span>
                          ))}
                        </div>
                    </div>
                  </div>

              {/* Premium Section */}
              <div className="relative">
                <div className={`glass-card p-8 sm:p-10 border-t-4 border-t-amber-500/50 ${!isPremium ? 'blur-md select-none opacity-50' : ''}`}>
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="text-2xl font-bold text-white flex items-center glow-text">
                      <Sparkles className="w-6 h-6 mr-3 text-amber-400" /> Premium Insights
                    </h3>
                    {isPremium && <span className="text-emerald-400 font-mono text-sm flex items-center bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20"><CheckCircle className="w-4 h-4 mr-2"/> UNLOCKED</span>}
                  </div>

                  <div className="space-y-10">
                    <div>
                      <h4 className="font-semibold text-white/90 mb-4 flex items-center">
                        <Building2 className="w-5 h-5 mr-3 text-brand-400" /> Top Hiring Companies
                      </h4>
                      <div className="flex flex-wrap gap-3">
                        {result.topCompanies.map((company, i) => (
                          <span key={i} className="bg-white/5 border border-white/10 text-white/80 px-5 py-2 rounded-xl text-sm hover:bg-white/10 transition-colors">
                            {company}
                          </span>
                        ))}
                      </div>
                    </div>

                    {mode === 'branch' && result.learningRoadmap && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <MapPin className="w-5 h-5 mr-3 text-indigo-400" /> Complete Placement Roadmap
                        </h4>
                        <div className="space-y-4">
                          {result.learningRoadmap.map((step, i) => (
                            <div key={i} className="flex gap-5 group">
                              <div className="flex-shrink-0 w-10 h-10 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl flex items-center justify-center font-bold text-sm group-hover:bg-indigo-500/20 transition-colors">
                                {i + 1}
                              </div>
                              <div className="bg-white/5 border border-white/10 p-5 rounded-2xl flex-1 group-hover:bg-white/10 transition-colors">
                                <p className="text-white/70 text-sm leading-relaxed">{step}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.studyTimeline && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Calendar className="w-5 h-5 mr-3 text-brand-400" /> Study Timeline
                        </h4>
                        <div className="grid gap-4 sm:grid-cols-2">
                          {result.studyTimeline.map((timeline, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
                              <div className="flex justify-between items-center mb-4">
                                <span className="font-bold text-brand-400 font-mono text-sm">{timeline.period}</span>
                                <span className="text-[10px] font-bold uppercase tracking-widest bg-brand-500/10 text-brand-400 px-2 py-1 rounded border border-brand-500/20">{timeline.focus}</span>
                              </div>
                              <ul className="space-y-2">
                                {timeline.tasks.map((task, j) => (
                                  <li key={j} className="text-white/50 text-xs flex items-start">
                                    <span className="mr-2 text-brand-500">•</span> {task}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.recommendedCourses && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <PlayCircle className="w-5 h-5 mr-3 text-rose-400" /> Recommended Courses
                        </h4>
                        <div className="grid sm:grid-cols-2 gap-4">
                          {result.recommendedCourses.map((course, i) => (
                            <a key={i} href={course.url} target="_blank" rel="noopener noreferrer" className="block bg-white/5 border border-white/10 p-5 rounded-2xl hover:bg-white/10 transition-all group">
                              <div className="flex justify-between items-start mb-3">
                                <h5 className="font-bold text-white text-sm group-hover:text-brand-400 transition-colors line-clamp-2">{course.title}</h5>
                                <ExternalLink className="w-4 h-4 text-white/30 group-hover:text-brand-400 flex-shrink-0 ml-3" />
                              </div>
                              <div className="flex items-center justify-between mt-4">
                                <span className="text-[10px] font-mono uppercase tracking-wider text-white/40">{course.platform}</span>
                                {course.isFree ? (
                                  <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">Free</span>
                                ) : (
                                  <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400 bg-amber-500/10 px-2 py-1 rounded border border-amber-500/20">Paid</span>
                                )}
                              </div>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.topProjects && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Code className="w-5 h-5 mr-3 text-emerald-400" /> Top Projects for Beginners
                        </h4>
                        <div className="space-y-4">
                          {result.topProjects.map((project, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
                              <div className="flex justify-between items-start mb-3">
                                <h5 className="font-bold text-white">{project.name}</h5>
                                <span className="text-[10px] font-bold uppercase tracking-widest bg-white/5 text-white/40 px-2 py-1 rounded border border-white/10">{project.difficulty}</span>
                              </div>
                              <p className="text-sm text-white/60 leading-relaxed">{project.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.internshipStrategy && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Briefcase className="w-5 h-5 mr-3 text-blue-400" /> Internship & Job Search Strategy
                        </h4>
                        <div className="bg-blue-500/5 border border-blue-500/10 p-6 rounded-2xl space-y-4">
                          {result.internshipStrategy.map((strategy, i) => (
                            <div key={i} className="flex items-start">
                              <CheckCircle className="w-4 h-4 text-blue-400 mr-4 flex-shrink-0 mt-1" />
                              <p className="text-white/70 text-sm leading-relaxed">{strategy}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.valuableCertifications && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Award className="w-5 h-5 mr-3 text-amber-400" /> Valuable Certifications
                        </h4>
                        <div className="flex flex-wrap gap-3">
                          {result.valuableCertifications.map((cert, i) => (
                            <span key={i} className="bg-amber-500/5 border border-amber-500/10 text-amber-400 px-4 py-2 rounded-xl text-sm font-medium">
                              {cert}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'branch' && result.linkedinNetworkingTips && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Users className="w-5 h-5 mr-3 text-blue-400" /> LinkedIn & Networking Strategy
                        </h4>
                        <div className="bg-blue-500/5 border border-blue-500/10 p-6 rounded-2xl space-y-4">
                          {result.linkedinNetworkingTips.map((tip, i) => (
                            <div key={i} className="flex items-start">
                              <CheckCircle className="w-4 h-4 text-blue-400 mr-4 flex-shrink-0 mt-1" />
                              <p className="text-white/70 text-sm leading-relaxed">{tip}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.skillGapAnalysis && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Target className="w-5 h-5 mr-3 text-rose-400" /> Skill Gap Analysis
                        </h4>
                        <div className="space-y-6">
                          {result.skillGapAnalysis.map((gap, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl">
                              <div className="flex justify-between items-center mb-4">
                                <h5 className="font-bold text-white">{gap.role}</h5>
                                <span className="text-xs font-bold text-rose-400 bg-rose-500/10 px-3 py-1 rounded-full border border-rose-500/20">
                                  {gap.matchPercentage}% Match
                                </span>
                              </div>
                              <div className="w-full bg-white/5 rounded-full h-2 mb-6 overflow-hidden">
                                <div className="bg-gradient-to-r from-rose-500 to-orange-400 h-2 rounded-full" style={{ width: `${gap.matchPercentage}%` }}></div>
                              </div>
                              <p className="text-xs text-white/40 mb-3 font-mono uppercase tracking-wider">Missing Skills to Acquire</p>
                              <div className="flex flex-wrap gap-2">
                                {gap.missingSkills.map((skill, j) => (
                                  <span key={j} className="bg-white/5 border border-white/10 text-white/70 px-3 py-1.5 rounded-lg text-xs">
                                    {skill}
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.upskillSprintPlan && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Rocket className="w-5 h-5 mr-3 text-emerald-400" /> Accelerated Upskill Sprint
                        </h4>
                        <div className="grid gap-4 sm:grid-cols-2">
                          {result.upskillSprintPlan.map((sprint, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
                              <div className="flex justify-between items-center mb-4">
                                <span className="font-bold text-emerald-400 font-mono text-sm">{sprint.phase}</span>
                                <span className="text-[10px] font-bold uppercase tracking-widest bg-emerald-500/10 text-emerald-400 px-2 py-1 rounded border border-emerald-500/20">{sprint.focus}</span>
                              </div>
                              <ul className="space-y-2">
                                {sprint.tasks.map((task, j) => (
                                  <li key={j} className="text-white/50 text-xs flex items-start">
                                    <span className="mr-2 text-emerald-500">•</span> {task}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.portfolioProjects && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <Layers className="w-5 h-5 mr-3 text-indigo-400" /> Targeted Portfolio Projects
                        </h4>
                        <div className="space-y-4">
                          {result.portfolioProjects.map((project, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
                              <h5 className="font-bold text-white mb-3">{project.title}</h5>
                              <p className="text-sm text-white/60 leading-relaxed mb-4">{project.description}</p>
                              <div className="flex flex-wrap gap-2">
                                {project.techStack.map((tech, j) => (
                                  <span key={j} className="text-[10px] font-mono uppercase tracking-widest bg-indigo-500/10 text-indigo-400 px-2 py-1 rounded border border-indigo-500/20">
                                    {tech}
                                  </span>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.monetizationOpportunities && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <DollarSign className="w-5 h-5 mr-3 text-amber-400" /> Immediate Monetization Avenues
                        </h4>
                        <div className="bg-amber-500/5 border border-amber-500/10 p-6 rounded-2xl space-y-4">
                          {result.monetizationOpportunities.map((opp, i) => (
                            <div key={i} className="flex items-start">
                              <TrendingUp className="w-4 h-4 text-amber-400 mr-4 flex-shrink-0 mt-1" />
                              <p className="text-white/70 text-sm leading-relaxed">{opp}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.atsKeywords && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <FileText className="w-5 h-5 mr-3 text-indigo-400" /> ATS Resume Keywords
                        </h4>
                        <p className="text-xs text-white/40 mb-4 font-mono uppercase tracking-wider">Include these exact keywords to beat HR filters</p>
                        <div className="flex flex-wrap gap-2">
                          {result.atsKeywords.map((keyword, i) => (
                            <span key={i} className="bg-indigo-500/5 border border-indigo-500/10 text-indigo-400 px-4 py-2 rounded-xl text-xs font-medium">
                              {keyword}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.interviewQuestions && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <MessageSquare className="w-5 h-5 mr-3 text-emerald-400" /> Top Interview Questions
                        </h4>
                        <div className="space-y-4">
                          {result.interviewQuestions.map((q, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
                              <h5 className="font-bold text-white mb-3 flex items-start">
                                <span className="text-emerald-400 mr-3 font-mono">Q:</span> {q.question}
                              </h5>
                              <div className="bg-amber-500/5 border border-amber-500/10 p-4 rounded-xl">
                                <p className="text-xs text-white/60 flex items-start">
                                  <span className="text-amber-400 font-bold mr-3 uppercase tracking-widest text-[10px] mt-0.5">Hint</span> {q.hint}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.jobRetentionTips && (
                      <div>
                        <h4 className="font-semibold text-white/90 mb-6 flex items-center">
                          <ShieldCheck className="w-5 h-5 mr-3 text-emerald-400" /> Job Security & Performance Tips
                        </h4>
                        <div className="space-y-3">
                          {result.jobRetentionTips.map((tip, i) => (
                            <div key={i} className="flex items-start bg-emerald-500/5 border border-emerald-500/10 p-5 rounded-2xl">
                              <CheckCircle className="w-4 h-4 text-emerald-400 mr-4 flex-shrink-0 mt-1" />
                              <p className="text-white/70 text-sm leading-relaxed">{tip}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {mode === 'skills' && result.jobVacancies && result.jobVacancies.length > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-6">
                          <h4 className="font-semibold text-white/90 flex items-center">
                            <Bell className="w-5 h-5 mr-3 text-rose-400" /> Skill-Based Job Alerts
                          </h4>
                          {isPremium && (
                            <span className="text-[10px] font-bold uppercase tracking-widest bg-rose-500/10 text-rose-400 px-3 py-1 rounded-full border border-rose-500/20 animate-pulse">
                              New Matches Found
                            </span>
                          )}
                        </div>
                        <div className="space-y-4">
                          {result.jobVacancies.map((job, i) => (
                            <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-all">
                              <div className="flex justify-between items-start mb-4">
                                <div>
                                  <h5 className="font-bold text-white text-lg mb-2">{job.jobRole}</h5>
                                  <div className="flex flex-wrap items-center gap-4 text-white/40">
                                    <div className="flex items-center text-xs">
                                      <Building2 className="w-3.5 h-3.5 mr-2 text-brand-400" />
                                      {job.companyName}
                                    </div>
                                    <div className="flex items-center text-xs">
                                      <MapPin className="w-3.5 h-3.5 mr-2 text-brand-400" />
                                      {job.location}
                                    </div>
                                  </div>
                                </div>
                                <Button 
                                  className="text-[10px] font-bold uppercase tracking-widest py-2 px-4 h-auto bg-brand-500 hover:bg-brand-400 text-white border-none shadow-[0_0_15px_rgba(139,92,246,0.3)]"
                                  onClick={() => {
                                    if (job.applyUrl) {
                                      window.open(job.applyUrl, '_blank');
                                    } else {
                                      const query = encodeURIComponent(`${job.jobRole} at ${job.companyName} ${job.location} apply`);
                                      window.open(`https://www.google.com/search?q=${query}`, '_blank');
                                    }
                                  }}
                                >
                                  Apply Now
                                </Button>
                              </div>
                              <div className="mt-5 pt-5 border-t border-white/5">
                                <p className="text-[10px] text-white/30 mb-3 font-mono uppercase tracking-widest">Required Skills</p>
                                <div className="flex flex-wrap gap-2">
                                  {job.requiredSkills.map((skill, j) => (
                                    <span key={j} className="bg-white/5 text-white/60 text-[10px] px-3 py-1 rounded-lg border border-white/5">
                                      {skill}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="bg-amber-500/5 border border-amber-500/10 p-8 rounded-2xl">
                      <h4 className="font-bold text-amber-400 mb-3 flex items-center text-sm uppercase tracking-widest">
                        <Sparkles className="w-4 h-4 mr-3" /> Pro Strategy
                      </h4>
                      <p className="text-white/70 italic text-sm leading-relaxed">"{result.premiumAdvice}"</p>
                    </div>
                  </div>
                </div>

                {/* Lock Overlay */}
                {!isPremium && (
                  <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/40 backdrop-blur-md rounded-3xl">
                    <div className="glass-card p-10 max-w-md w-full mx-4 border-amber-500/30 relative overflow-hidden text-center">
                      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-amber-500/50 to-transparent"></div>
                      
                      <div className="w-20 h-20 bg-amber-500/10 text-amber-400 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-amber-500/20 shadow-[0_0_30px_rgba(245,158,11,0.1)]">
                        <Lock className="w-10 h-10" />
                      </div>
                      <h3 className="text-3xl font-bold text-white mb-3 glow-text">Unlock Full Blueprint</h3>
                      <p className="text-white/50 mb-8 text-sm leading-relaxed">
                        Get exclusive access to your personalized career roadmap, hiring companies, and interview strategies.
                      </p>
                      
                      <div className="bg-white/5 rounded-2xl p-6 mb-8 border border-white/5 text-left">
                        <ul className="space-y-4">
                          {mode === 'skills' ? (
                            <>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Skill Gap Analysis & Match %</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Accelerated Upskill Sprint Plan</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Targeted Portfolio Projects</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Immediate Monetization Avenues</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Live Job Vacancies & Apply Links</span></li>
                            </>
                          ) : (
                            <>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Step-by-Step Placement Roadmap</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Semester-wise Study Timeline</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Curated Free & Paid Courses</span></li>
                              <li className="flex items-start"><CheckCircle className="w-5 h-5 text-emerald-400 mr-4 shrink-0" /><span className="text-sm text-white/70">Top Projects & Internship Strategy</span></li>
                            </>
                          )}
                        </ul>
                      </div>

                      <Button onClick={handleUnlock} className="w-full bg-gradient-to-r from-amber-600 to-amber-400 hover:from-amber-500 hover:to-amber-300 text-white font-bold text-lg py-7 rounded-2xl shadow-[0_10px_40px_rgba(245,158,11,0.2)] transition-all transform hover:scale-[1.02] active:scale-[0.98]">
                        Unlock Report for ₹99
                      </Button>
                      <p className="text-[10px] font-mono uppercase tracking-widest text-white/30 mt-6">
                        One-time payment • Lifetime access
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-center gap-4">
                <Button onClick={handleReset} variant="outline">
                  Start Over
                </Button>
                {isPremium && (
                  <Button onClick={() => window.print()} variant="ghost">
                    Save / Print
                  </Button>
                )}
              </div>
              </>
            )}
            </motion.div>
          )}
        </AnimatePresence>
          {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            className="glass-card max-w-md w-full overflow-hidden border-white/20"
          >
            <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
              <h3 className="text-xl font-bold text-white glow-text">
                {paymentStep === 'options' ? 'Complete Payment' : 'Pay via UPI'}
              </h3>
              <button onClick={() => setShowPaymentModal(false)} className="text-white/40 hover:text-white transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-8 space-y-8">
              <div className="flex flex-col items-center space-y-8">
                <div className="text-center">
                  <p className="text-white/40 mb-2 font-mono text-xs uppercase tracking-widest">Scan to Pay</p>
                  <p className="text-5xl font-bold text-white glow-text">₹99</p>
                </div>
                
                <div className="bg-white p-6 rounded-3xl shadow-[0_0_50px_rgba(255,255,255,0.1)]">
                  {/* Display the dynamic PhonePe QR Code */}
                  <QRCodeSVG value={upiLink} size={220} level="H" />
                </div>
                
                <div className="text-center space-y-2">
                  <p className="text-sm text-white/60">
                    Scan with PhonePe, GPay, or Paytm
                  </p>
                  <div className="flex justify-center gap-4 opacity-40 grayscale">
                    {/* Placeholder logos or icons for UPI apps */}
                    <div className="w-8 h-8 bg-white/10 rounded-lg" />
                    <div className="w-8 h-8 bg-white/10 rounded-lg" />
                    <div className="w-8 h-8 bg-white/10 rounded-lg" />
                  </div>
                </div>

                <div className="w-full space-y-5">
                  {!showUtrInput && (
                    <a 
                      href={upiLink}
                      className="w-full flex items-center justify-center px-4 py-4 bg-brand-500 text-white font-bold rounded-2xl hover:bg-brand-400 transition-all sm:hidden shadow-[0_10px_30px_rgba(99,102,241,0.2)]"
                    >
                      Open UPI App
                    </a>
                  )}

                  {showUtrInput && (
                    <div className="w-full animate-in fade-in slide-in-from-bottom-2 duration-300">
                      <label className="block text-xs font-mono uppercase tracking-widest text-white/40 mb-2">
                        Enter 12-digit UTR / Transaction ID
                      </label>
                      <input
                        type="text"
                        value={utrNumber}
                        onChange={(e) => setUtrNumber(e.target.value.replace(/\D/g, '').slice(0, 12))}
                        placeholder="e.g. 312345678901"
                        className="w-full bg-white/5 border border-white/10 px-5 py-4 rounded-2xl text-white placeholder:text-white/20 focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500/50 outline-none transition-all font-mono"
                        maxLength={12}
                      />
                      {utrError && <p className="text-rose-400 text-[10px] mt-2 font-mono uppercase tracking-wider">{utrError}</p>}
                    </div>
                  )}

                  <Button 
                    onClick={handlePaymentSuccess} 
                    className="w-full bg-white/10 hover:bg-white/20 text-white border border-white/10 py-7 rounded-2xl transition-all"
                    disabled={isVerifying}
                  >
                    {isVerifying ? (
                      <span className="flex items-center">
                        <Loader2 className="w-4 h-4 mr-3 animate-spin" /> Verifying...
                      </span>
                    ) : showUtrInput ? "Verify Payment" : "I have paid ₹99"}
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      </main>

      <footer className="py-12 text-center text-white/30 text-xs font-mono uppercase tracking-widest border-t border-white/5 mt-20">
        <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 mb-6">
          <a href="/terms" className="hover:text-brand-400 transition-colors">Terms & Conditions</a>
          <a href="/privacy" className="hover:text-brand-400 transition-colors">Privacy Policy</a>
          <a href="/refund" className="hover:text-brand-400 transition-colors">Refund Policy</a>
          <a href="/contact" className="hover:text-brand-400 transition-colors">Contact Us</a>
        </div>
        <p>© {new Date().getFullYear()} CareerPath AI • Powered by Gemini 3.1</p>
      </footer>
    </div>
  );
}
