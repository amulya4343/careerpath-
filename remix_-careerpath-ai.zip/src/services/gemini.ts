import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini API client lazily to prevent crashes on load if key is missing
let ai: GoogleGenAI | null = null;

function getAiClient() {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error("GEMINI_API_KEY is missing!");
      throw new Error("API Key is missing. Please configure it in the secrets panel.");
    }
    ai = new GoogleGenAI({ apiKey });
  }
  return ai;
}

export interface JobVacancy {
  companyName: string;
  jobRole: string;
  requiredSkills: string[];
  location: string;
  applyUrl: string; // Made mandatory
}

export interface CareerAnalysisData {
  skillsEntered?: string;
  jobRoles: string[];
  expectedSalary: string;
  marketDemandIndex: number; // 0-100 score
  careerConfidenceScore: number; // 0-100 score
  topCompanies: string[]; // Premium
  skillsToLearn: string[];
  learningRoadmap?: string[]; // Premium (Specific to 'branch' mode)
  jobRetentionTips?: string[]; // Premium (Specific to 'skills' mode)
  jobVacancies?: JobVacancy[]; // Premium (Specific to 'skills' mode)
  premiumAdvice: string; // Premium
  
  // NEW FIELDS for 'branch' mode
  recommendedCourses?: { title: string; platform: string; url: string; isFree: boolean }[];
  studyTimeline?: { period: string; focus: string; tasks: string[] }[];
  topProjects?: { name: string; description: string; difficulty: string }[];
  internshipStrategy?: string[];
  valuableCertifications?: string[]; // Premium (Specific to 'branch' mode)
  linkedinNetworkingTips?: string[]; // Premium (Specific to 'branch' mode)

  // NEW FIELDS for 'skills' mode
  atsKeywords?: string[]; // Premium (Specific to 'skills' mode)
  interviewQuestions?: { question: string; hint: string }[]; // Premium (Specific to 'skills' mode)
  
  // ADVANCED SKILL MAPPING FEATURES
  skillGapAnalysis?: { role: string; matchPercentage: number; missingSkills: string[] }[];
  portfolioProjects?: { title: string; description: string; techStack: string[] }[];
  upskillSprintPlan?: { phase: string; focus: string; tasks: string[] }[];
  monetizationOpportunities?: string[];
}

const MODEL_NAME = "gemini-3-flash-preview";

export async function analyzeSkills(skills: string): Promise<CareerAnalysisData> {
  const client = getAiClient();
  const prompt = `
You are an AI career assistant for college students in India.
The student has the following skills: "${skills}".

Return a JSON object with the following structure:
{
  "jobRoles": ["Role 1", "Role 2", ...],
  "expectedSalary": "Range in INR (e.g. ₹3,00,000 - ₹5,00,000)",
  "marketDemandIndex": 85,
  "careerConfidenceScore": 72,
  "topCompanies": ["Company 1", "Company 2", ...],
  "skillsToLearn": ["Skill 1", "Skill 2", "Skill 3"],
  "skillGapAnalysis": [
    { "role": "Target Role 1", "matchPercentage": 75, "missingSkills": ["Missing 1", "Missing 2"] }
  ],
  "portfolioProjects": [
    { "title": "Project Name", "description": "What to build to prove these skills", "techStack": ["Skill 1", "Skill 2"] }
  ],
  "upskillSprintPlan": [
    { "phase": "Weeks 1-2", "focus": "Core Concepts", "tasks": ["Task 1", "Task 2"] }
  ],
  "monetizationOpportunities": ["Freelance Idea 1", "Side Hustle 2"],
  "jobRetentionTips": [
    "Tip 1: How to stay relevant...",
    "Tip 2: Workplace etiquette...",
    "Tip 3: Performance tip..."
  ],
  "atsKeywords": ["Keyword 1", "Keyword 2", "Keyword 3"],
  "interviewQuestions": [
    { "question": "Common interview question 1?", "hint": "How to answer it effectively." },
    { "question": "Common interview question 2?", "hint": "How to answer it effectively." }
  ],
  "jobVacancies": [
    {
      "companyName": "Tech Corp",
      "jobRole": "Frontend Developer",
      "requiredSkills": ["React", "TypeScript"],
      "location": "Bangalore / Remote",
      "applyUrl": "https://www.naukri.com/job-listings-..."
    }
  ],
  "premiumAdvice": "A short, high-value tip for cracking interviews in this domain."
}

IMPORTANT: "jobRetentionTips" should provide actionable advice on how to perform well in these roles and avoid layoffs/job loss.
"atsKeywords" MUST be the exact buzzwords HR software looks for on resumes for these roles.
"interviewQuestions" MUST provide the top 3-5 most frequently asked technical or behavioral questions for these skills.
"jobVacancies" MUST be based on realistic, current job openings in India matching the user's skills. Provide 5-6 examples of recent job postings.
"applyUrl" is MANDATORY. You MUST provide a DIRECT link to the job application page (e.g., LinkedIn, Naukri, Indeed, or the company's direct career site). Do not leave it empty.
`;

  try {
    const response = await client.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    
    let text = response.text || "{}";
    text = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    return JSON.parse(text);
  } catch (error: any) {
    console.error("Error analyzing skills:", error);
    if (error.message && error.message.includes("API Key")) {
      throw new Error("API Key is missing. Please configure it in your hosting dashboard.");
    }
    throw new Error(`Failed to analyze skills: ${error.message || "Unknown error"}`);
  }
}

export async function suggestPathByBranch(branch: string): Promise<CareerAnalysisData> {
  const client = getAiClient();
  const prompt = `
You are an AI career assistant for college students in India.
The student is from the "${branch}" branch and is just starting their career journey.

Return a JSON object with the following structure:
{
  "jobRoles": ["Role 1", "Role 2", ...],
  "expectedSalary": "Range in INR (e.g. ₹3,00,000 - ₹5,00,000)",
  "marketDemandIndex": 90,
  "careerConfidenceScore": 65,
  "topCompanies": ["Company 1", "Company 2", ...],
  "skillsToLearn": ["Skill 1", "Skill 2", "Skill 3", "Skill 4"],
  "learningRoadmap": [
    "Step 1: [Basics] - ...",
    "Step 2: [Intermediate] - ...",
    "Step 3: [Projects] - ...",
    "Step 4: [Advanced] - ...",
    "Step 5: [Placement Prep] - ..."
  ],
  "recommendedCourses": [
    { "title": "Course Name", "platform": "Coursera/Udemy/YouTube", "url": "https://...", "isFree": true }
  ],
  "studyTimeline": [
    { "period": "Semester 1-2 (or Month 1-2)", "focus": "Core Basics", "tasks": ["Task 1", "Task 2"] }
  ],
  "topProjects": [
    { "name": "Project Name", "description": "Brief description", "difficulty": "Beginner/Intermediate" }
  ],
  "internshipStrategy": [
    "Tip 1: Where to apply...",
    "Tip 2: Resume building..."
  ],
  "valuableCertifications": [
    "Certification 1 (e.g., AWS Certified Cloud Practitioner)",
    "Certification 2"
  ],
  "linkedinNetworkingTips": [
    "Tip 1: How to optimize profile...",
    "Tip 2: How to reach out to alumni..."
  ],
  "premiumAdvice": "A short, high-value tip for career growth in this field."
}

IMPORTANT: The "learningRoadmap" must be a COMPLETE, detailed, step-by-step guide from absolute beginner (Step 1) to being placement-ready.
Provide at least 3 recommended courses, 4 study timeline periods, 3 top projects, 3 internship strategy tips, 2 valuable certifications, and 3 LinkedIn networking tips.
`;

  try {
    const response = await client.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    
    let text = response.text || "{}";
    text = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    return JSON.parse(text);
  } catch (error: any) {
    console.error("Error suggesting path:", error);
    if (error.message && error.message.includes("API Key")) {
      throw new Error("API Key is missing. Please configure it in your hosting dashboard.");
    }
    throw new Error(`Failed to suggest path: ${error.message || "Unknown error"}`);
  }
}
